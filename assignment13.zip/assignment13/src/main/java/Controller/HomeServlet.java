package Controller;

import Model.Quiz;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/home")
public class HomeServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int counter = 0;
        HttpSession session = req.getSession();
        session.setAttribute("counter", counter);
        session.setAttribute("nextQuestion", "3,1,4,1,5");
        RequestDispatcher rd = req.getRequestDispatcher("quiz.jsp");
        rd.forward(req,resp);
    }
}
