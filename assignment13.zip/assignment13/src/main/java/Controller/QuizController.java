package Controller;

import Model.Quiz;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/quiz")
public class QuizController extends HttpServlet {
    String[] pi = {"3,1,4,1,5"};
    String[] fibonacci = {"1,1,2,3,5"};
    String[] squares = {"1,4,9,16,25"};
    String[] primes = {"2,3,5,7,11"};
    String[] powerOf2 = {"1,2,4,8,16"};

    Quiz pi_quiz = new Quiz(pi, 9);
    Quiz fib = new Quiz(fibonacci, 8);
    Quiz sqrt = new Quiz(squares, 36);
    Quiz pri = new Quiz(primes, 13);
    Quiz powerOfTwo = new Quiz(powerOf2, 32);

    String nextQuestion[] = {fib.getQuestions(), sqrt.getQuestions(), pri.getQuestions(), powerOfTwo.getQuestions()};
    Integer answers[] = {pi_quiz.getAnswers(), fib.getAnswers(), sqrt.getAnswers(), pri.getAnswers(), powerOfTwo.getAnswers()};

    int i = 0;
    int j = 0;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RequestDispatcher rd = req.getRequestDispatcher("quiz.jsp");
        rd.forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        int answer = Integer.parseInt(req.getParameter("answer"));
        if (i <= 3) {
            session.setAttribute("nextQuestion", nextQuestion[i++]);
        }
        if (answer == answers[j]) {

            int counter = (Integer) session.getAttribute("counter");
            session.setAttribute("counter", ++counter);
        }if(j<=4) j++;

        if (i != 4) {
            resp.sendRedirect("quiz");
        } else {
            RequestDispatcher rd = req.getRequestDispatcher("result.jsp");
            rd.forward(req, resp);
        }
    }
}
