package edu.mum.cs;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class addServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse
            response) throws ServletException, IOException {
        int n1 = Integer.parseInt(request.getParameter("n1"));
        int n2 = Integer.parseInt(request.getParameter("n2"));
        int n3 = Integer.parseInt(request.getParameter("n3"));
        int n4 = Integer.parseInt(request.getParameter("n4"));
        int sum = n1 + n2;
        int mul = n3*n4;
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
//        out.println(n1 + "+" + n2 + "=" +  sum);
//        out.println(n1 + "*" + n2 + "=" +  mul);
        out.println("<form action=\'#\' method=\'get\'>");
        out.println("<div>");
        out.println("<input type=\'text\' name=\'n1\' placeholder=\'n1\' value = " +n1+ ">" + " + ");
        out.println("<input type=\'text\' name=\'n2\' placeholder=\'n2\' value = " +n2+  "> " + " = ");
        out.println("<input type=\'text\' value= " +sum+ "  >");
        out.println("<div>");
        out.println("<input type=\'text\' name=\'n3\' placeholder=\'n3\' value = " +n3+ ">" + " + ");
        out.println("<input type=\'text\' name=\'n4\' placeholder=\'n4\' value = " +n4+  "> " + " = ");
        out.println("<input type=\'text\' value= " +mul+ "  >");
        out.println("<div>");
        out.println("<div>");
        out.println("<input type=\'submit\'>");
        out.println("<div>");
        out.println("</form>");


    }
}
